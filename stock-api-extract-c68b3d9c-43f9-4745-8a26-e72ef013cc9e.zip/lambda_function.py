import json
import pandas as pd
import requests
import boto3
import con as con
from io import StringIO

sns = boto3.client("sns", region_name="eu-north-1")
ssm = boto3.client("ssm", region_name="eu-north-1")


# github_api_url = ssm.get_parameter(Name=con.urlapi, WithDecryption=True)["Parameter"]["Value"]

def send_sns_success():
    success_sns_arn = ssm.get_parameter(Name=con.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = con.COMPONENT_NAME
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    success_msg = con.SUCCESS_MSG
    sns_message = (f"{component_name} :  {success_msg}")
    print(sns_message, 'text')
    succ_response = sns.publish(TargetArn=success_sns_arn, Message=json.dumps({'default': json.dumps(sns_message)}),
                                Subject=env + " : " + component_name, MessageStructure="json")
    return succ_response


def send_error_sns(msg):
    error_sns_arn = ssm.get_parameter(Name=con.ERRORNOTIFICATIONARN)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    error_message = con.ERROR_MSG + msg
    component_name = con.COMPONENT_NAME
    sns_message = (f"{component_name} : {error_message}")
    err_response = sns.publish(TargetArn=error_sns_arn, Message=json.dumps({'default': json.dumps(sns_message)}),
                               Subject=env + " : " + component_name,
                               MessageStructure="json")
    return err_response


def lambda_handler(event, context):
    try:
        url = ssm.get_parameter(Name=con.urlapi, WithDecryption=True)["Parameter"]["Value"]
        # url1 = 'https://api.github.com/repos/squareshift/stock_analysis/content/'
        # response = requests.get(github_api_url)
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for HTTP errors
        files = response.json()
        csv_files = [file['download_url'] for file in files if file['name'].endswith('.csv')]
        print(csv_files)
        csv_file = csv_files.pop()
        print(csv_file)
        d = pd.read_csv(csv_file)
        print(d)

        dataframes = []
        file_names = []
        for url in csv_files:
            file_name = url.split("/")[-1].replace(".csv", "")
            print(file_name)
            df = pd.read_csv(url)
            print(df)
            df['Symbol'] = file_name
            dataframes.append(df)
            file_names.append(file_name)
        print('file_names: ',file_names)
        combined_df = pd.concat(dataframes, ignore_index=True)
        print('combined_df:',combined_df)
        o_df = pd.merge(combined_df, d, on='Symbol', how='left')
        print('o_df:',o_df)

        result = o_df.groupby("Sector").agg(
            {'open': 'mean', 'close': 'mean', 'high': 'max', 'low': 'min', 'volume': 'mean'}).reset_index()

        o_df["timestamp"] = pd.to_datetime(o_df["timestamp"])
        filtered_df = o_df[(o_df['timestamp'] >= "2021-01-01") & (o_df['timestamp'] <= "2021-05-26")]

        list_sector = ["TECHNOLOGY", "FINANCE"]
        result_time = filtered_df.groupby("Sector").agg(
            {'open': 'mean', 'close': 'mean', 'high': 'max', 'low': 'min', 'volume': 'mean'}).reset_index()
        result_time = result_time.rename(columns={'open': 'aggregate_open',
                                                  'close': 'aggregate_close',
                                                  'high': 'aggregate_high',
                                                  'low': 'aggregate_low',
                                                  'volume': 'aggregate_volume'})
        result_time = result_time[result_time["Sector"].isin(list_sector)].reset_index(drop=True)

        csv_buffer = StringIO()
        print(result_time)
        result_time.to_csv(csv_buffer, index=False)

        # Upload CSV to S3
        s3 = boto3.client('s3')
        bucket_name = 'stock-api95'
        key = 'apioutput/data/stock.csv'
        s3.put_object(Body=csv_buffer.getvalue(), Bucket=bucket_name, Key=key)
        send_sns_success()

        return {
            'statusCode': 200,
            'body': 'Data uploaded to S3 successfully!'
        }
    except Exception as e:
        print(e)
        msg = str(e)
        send_error_sns(msg)
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'

        }